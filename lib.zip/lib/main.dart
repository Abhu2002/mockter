import 'package:expt1_login/screens/home_screen.dart';
import 'package:flutter/material.dart';
import 'screens/registration_screen.dart';
import 'package:expt1_login/screens/login_screen.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:data_connection_checker_tv/data_connection_checker.dart';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:expt1_login/screens/network_error.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      routes: {
        LoginScreen.id: (context) => LoginScreen(),
        RegistrationScreen.id: (context) => RegistrationScreen(),
        HomeScreen.id: (context) => HomeScreen(),
        NetworkError.id: (context) => NetworkError(),
      },
      home: SafeArea(
        child: LoginScreen(),
      ),
    );
  }
}
