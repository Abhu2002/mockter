import 'package:flutter/material.dart';
import 'package:expt1_login/brains/login_brain.dart';
import 'package:flutter_awesome_alert_box/flutter_awesome_alert_box.dart';

class HomeScreen extends StatelessWidget {
  static String id = '/home_screen';
  late Map<String, dynamic> userdetails;
  @override
  Widget build(BuildContext context) {
    userdetails =
        ModalRoute.of(context)!.settings.arguments as Map<String, dynamic>;
    return Scaffold(
      body: SafeArea(
        child: Container(
          color: Colors.lightBlue,
          child: Column(
            children: [
              Center(
                child: Text(
                  "Welcome to My App",
                  style: TextStyle(
                    fontSize: 50.0,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                  ),
                ),
              ),
              Center(
                child: Text(userdetails['name'] ?? ""),
              ),
              Center(
                child: Text(userdetails['mobile'] ??
                    "No phone number associated with current account"),
              ),
              TextButton(
                child: Text(
                  "Log Out",
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 50.0,
                  ),
                ),
                onPressed: () async {
                  Login_Brain lb = Login_Brain();
                  await lb.doLogOutOfGoogle();
                  Future.delayed(
                      Duration.zero,
                      () => SuccessAlertBox(
                            context: context,
                            title: "LOGOUT SUCCESSFULL",
                            messageText: "You have successfully logged out",
                            buttonColor: Colors.blueAccent,
                            titleTextColor: Colors.blueAccent,
                          ));
                  Navigator.pop(context);
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}
